# slim-from-scratch
Code source for the blog series articles:

[- Introducing Slim 4 (Part 1)](https://dev.to/cherif_b/introducing-slim-4-55j9): the master branch

## Install

```shell
composer install
```

## Run the application
```shell
composer server
```

